# 根据选择的部分文件进行同样文件名，不同后缀名的文件筛选与复制

应用场景：数码相机的照片文件导出后，对每个照片会同时有两个不同后缀名的文件（.arw和.jpg）存在。选择文件时，由于jpg文件较小，一般会把全部jpg文件复制到另一个目录中进行浏览并筛选，对于选择好的jpg文件，希望能够根据其文件名到原有目录中搜索到对应的arw照片文件并将其复制到一个新的目录。

## 问题的提出

目前Windows的文件管理器虽然支持OR这样的搜索选项，但是无法实现对应每个指定的文件名去匹配另一个文件名相同而后缀名不同的文件，并进行后续复制操作。

## 方案

本工具利用Excel的VBA对文件目录和文件名称进行筛选匹配，并实现自动批量复制。

## 使用方法

1. 建立一个工作目录，将本工具（[filename_matching.xlsm](.\filename_matching.xlsm)）放到这个目录下
2. 在工作目录中创建三个子目录：source存放全部原始照片文件；sourcejpg存放选择好的jpg文件；targetraw初始为空，运行工具后会存放复制过来的匹配好的raw文件
3. 假定文件名的后缀为：arw, jpg
4. 需要在Excel中确认激活“宏”，允许运行

---
Author: Xiaoqi Zhao

Version History:

- 0.2, 2023/02/18, change target file extension from RAW to ARW
- draft 0.1, Date: 2023/02/18